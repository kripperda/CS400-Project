document.addEventListener("DOMContentLoaded", () => {
    let savedToys = JSON.parse(localStorage.getItem("savedToys")) || [];
    const savedContainer = document.getElementById("saved-toy-listings");

    if (savedToys.length === 0) {
        savedContainer.innerHTML = "<p>No saved listings yet.</p>";
        return;
    }

    fetch('data/listings.json') // Ensure the correct path
        .then(response => response.json())
        .then(toys => {
            let filteredToys = toys.filter(toy => savedToys.includes(toy.id.toString()));

            filteredToys.forEach(toy => {
                const toyCard = document.createElement("div");
                toyCard.classList.add("col-md-4");
                toyCard.innerHTML = `
                    <div class="card">
                        <img src="${toy.image}" class="card-img-top" alt="${toy.name}" onerror="this.onerror=null;this.src='images/placeholder.jpg';">
                        <div class="card-body">
                            <h5 class="card-title">${toy.name}</h5>
                            <p class="card-text">Age Group: ${toy.ageGroup}</p>
                            <p class="card-text">Location: ${toy.location}</p>
                            <p class="card-text">Type: ${toy.type}</p>
                            <p class="card-text">${toy.type === "for sale" ? `Price: $${toy.price}` : ""}</p>
                            <button class="btn btn-danger remove-btn" data-id="${toy.id}">Remove</button>
                        </div>
                    </div>
                `;
                savedContainer.appendChild(toyCard);
            });

            // Remove from saved listings
            document.querySelectorAll(".remove-btn").forEach(button => {
                button.addEventListener("click", (e) => {
                    let updatedToys = savedToys.filter(id => id !== e.target.dataset.id);
                    localStorage.setItem("savedToys", JSON.stringify(updatedToys));
                    e.target.closest(".col-md-4").remove();
                });
            });
        })
        .catch(error => console.error("Error loading saved toys:", error));
});
