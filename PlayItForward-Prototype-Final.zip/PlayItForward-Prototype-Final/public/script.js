document.addEventListener("DOMContentLoaded", () => {
    let allToys = []; // Store all toy listings

    fetch('data/listings.json')
        .then(response => response.json())
        .then(toys => {
            allToys = toys; // Save data globally
            populateFilters(toys); // Fill dropdowns dynamically
            displayListings(toys); // Display all listings initially
        })
        .catch(error => console.error("Error loading toys:", error));

    function displayListings(toys) {
        const toyContainer = document.getElementById("toy-listings");
        toyContainer.innerHTML = ""; // Clear previous listings

        if (toys.length === 0) {
            toyContainer.innerHTML = "<p>No toys found for selected filters.</p>";
            return;
        }

        toys.forEach(toy => {
            const toyCard = document.createElement("div");
            toyCard.classList.add("col-md-4");
            toyCard.innerHTML = `
                <div class="card">
                    <img src="${toy.image}" class="card-img-top" alt="${toy.name}" onerror="this.onerror=null;this.src='images/placeholder.jpg';">
                    <div class="card-body">
                        <h5 class="card-title">${toy.name}</h5>
                        <p class="card-text">Age Group: ${toy.ageGroup}</p>
                        <p class="card-text">Location: ${toy.location}</p>
                        <p class="card-text">Type: ${toy.type}</p>
                        <p class="card-text">${toy.type === "for sale" ? `Price: $${toy.price}` : ""}</p>
                        <button class="btn btn-primary save-btn" data-id="${toy.id}">Save Listing</button>
                    </div>
                </div>
            `;
            toyContainer.appendChild(toyCard);
        });

        attachSaveListeners(); // Attach event listeners to save buttons
    }

    function populateFilters(toys) {
        const locationFilter = document.getElementById("locationFilter");
        const ageFilter = document.getElementById("ageFilter");

        let locations = new Set();
        let ageRanges = new Set();

        // Standardized age ranges
        const allowedAgeRanges = ["0-1", "1-3", "3-5", "6-9", "10-13"];

        toys.forEach(toy => {
            locations.add(toy.location);

            // Normalize the age group to match allowed values
            const normalizedAge = allowedAgeRanges.find(range => toy.ageGroup.includes(range));
            if (normalizedAge) {
                ageRanges.add(normalizedAge);
            }
        });

        // Populate location dropdown
        locations.forEach(location => {
            let option = document.createElement("option");
            option.value = location;
            option.textContent = location;
            locationFilter.appendChild(option);
        });

        // Populate age filter with predefined values
        allowedAgeRanges.forEach(age => {
            let option = document.createElement("option");
            option.value = age;
            option.textContent = age;
            ageFilter.appendChild(option);
        });
    }

    document.getElementById("applyFilters").addEventListener("click", () => {
        const selectedLocation = document.getElementById("locationFilter").value;
        const selectedAge = document.getElementById("ageFilter").value;

        let filteredToys = allToys.filter(toy => {
            return (selectedLocation === "" || toy.location === selectedLocation) &&
                   (selectedAge === "" || selectedAge === toy.ageGroup);
        });

        displayListings(filteredToys);
    });

    function attachSaveListeners() {
        document.querySelectorAll(".save-btn").forEach(button => {
            button.addEventListener("click", (e) => {
                let savedToys = JSON.parse(localStorage.getItem("savedToys")) || [];
                const toyId = e.target.dataset.id;
                if (!savedToys.includes(toyId)) {
                    savedToys.push(toyId);
                    localStorage.setItem("savedToys", JSON.stringify(savedToys));
                    alert("Toy saved!");
                }
            });
        });
    }
});



