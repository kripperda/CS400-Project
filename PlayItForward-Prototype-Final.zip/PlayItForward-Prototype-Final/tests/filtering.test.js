/**
 * @jest-environment jsdom
 */
const { filterListings } = require("../script");

describe("Filtering Functionality", () => {
    const mockToys = [
        { id: 1, name: "Toy Car", location: "NY", ageGroup: "3-5" },
        { id: 2, name: "Doll", location: "CA", ageGroup: "1-3" },
        { id: 3, name: "Lego Set", location: "NY", ageGroup: "6-9" },
    ];

    it("Should return all listings when no filters are applied", () => {
        const result = filterListings(mockToys, "", "");
        expect(result.length).toBe(3);
    });

    it("Should return only listings matching the selected location", () => {
        const result = filterListings(mockToys, "NY", "");
        expect(result.length).toBe(2);
    });

    it("Should return only listings matching the selected age group", () => {
        const result = filterListings(mockToys, "", "1-3");
        expect(result.length).toBe(1);
    });

    it("Should return listings that match both location and age group", () => {
        const result = filterListings(mockToys, "NY", "6-9");
        expect(result.length).toBe(1);
        expect(result[0].name).toBe("Lego Set");
    });
});
