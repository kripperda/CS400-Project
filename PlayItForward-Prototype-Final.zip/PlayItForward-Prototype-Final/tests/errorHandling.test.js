describe("404 Error Handling", () => {
    it("Should return 404 for an unknown route", async () => {
        const response = await request(app).get("/unknown-route");
        expect(response.statusCode).toBe(404);
    });
});
