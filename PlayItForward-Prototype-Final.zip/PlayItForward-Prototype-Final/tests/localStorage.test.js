/**
 * @jest-environment jsdom
 */
describe("LocalStorage Save Functionality", () => {
    beforeEach(() => {
        localStorage.clear();
    });

    it("Should save an item to localStorage", () => {
        let savedToys = [];
        const toyId = "1";

        savedToys.push(toyId);
        localStorage.setItem("savedToys", JSON.stringify(savedToys));

        expect(localStorage.getItem("savedToys")).toBe(JSON.stringify(["1"]));
    });

    it("Should not add duplicate items", () => {
        let savedToys = ["1"];
        localStorage.setItem("savedToys", JSON.stringify(savedToys));

        const newId = "1";
        if (!savedToys.includes(newId)) {
            savedToys.push(newId);
            localStorage.setItem("savedToys", JSON.stringify(savedToys));
        }

        expect(JSON.parse(localStorage.getItem("savedToys")).length).toBe(1);
    });
});
