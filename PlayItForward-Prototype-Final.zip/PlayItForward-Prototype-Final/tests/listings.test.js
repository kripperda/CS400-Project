describe("Fetch Listings Data", () => {
    it("Should return a JSON object from /data/listings.json", async () => {
        const response = await request(app).get("/data/listings.json");
        expect(response.statusCode).toBe(200);
        expect(response.headers["content-type"]).toContain("application/json");
    });

    it("Should contain at least one toy listing", async () => {
        const response = await request(app).get("/data/listings.json");
        const listings = response.body;
        expect(Array.isArray(listings)).toBe(true);
        expect(listings.length).toBeGreaterThan(0);
    });
});
